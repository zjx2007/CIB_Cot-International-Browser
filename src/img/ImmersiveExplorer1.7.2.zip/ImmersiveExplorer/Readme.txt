Immersive Explorer
version 1.7.2
https://www.immersive-explorer.com
Created by Julien MANICI (email/Skype: jmanici@outlook.com)
=================================

Immersive Explorer is an alternative to the default file explorer included in Windows (known as Windows Explorer).
It is designed to provide an "immersive" experience to the user by focusing on the content rather than hiding it 
behind icons and large window chrome and borders. It allows the user to avoid opening different applications and 
switching between multiple windows when doing tasks as simple as viewing a picture, thanks to the built-in viewer.

Although it is not a Windows 8 "Metro application", Immersive Explorer is designed around the "Metro" user interface 
guidelines. It is optimized for tablets and computers with touch-screens, but it also offers a great experience for 
mouse/keyboard users (with features like scroll-to-zoom, keyboard navigation).

Immersive Explorer is based on Win32/.NET/WPF (Windows Presentation Foundation). It uses graphical hardware 
acceleration to display fluid animations and transitions, making it look more modern than the default Windows 
File Explorer. Note that it's not a complete replacement for the Windows Shell (it's just an alternative to the
Windows Explorer) and it doesn't even need administrator rights to be installed.


Configuration required : 
=================================

-Windows 7, Windows 8.1 or Windows 10.
-At least a Dual Core CPU
-At least 2 GB of RAM
-The .NET Framework 4.5 must be installed (it is already installed by default on Windows 10 and 8.1, but not on Windows 7)


Deployment (for advanced users) : 
=================================

Immersive Explorer installs in the user profile, and doesn't require administrator rights during setup.
Path: %userprofile%\AppData\Local\immersive-explorer.com\

Supported command line parameters:
-Silent install: /install
-Silent uninstall: /uninstall
Note: A silent install will skip update check/download. Instead, update availability will be checked on application first start.

ImmersiveExplorerFavoriteFolders.conf can expand these environment variables: %userprofile% and "%public%
You can remove all the content of ImmersiveExplorerFavoriteFolders.conf to prevent Favorite Folders from displaying.

To deploy your own settings automatically, you can put "ImmersiveExplorerSettings.conf" and/or "ImmersiveExplorerFavoriteFolders.conf" 
in the same folder as the setup program ("SetupImmersiveExplorer.exe"), and they will be copied to the installation folder during 
installation.

"ImmersiveExplorerSettings.conf" contains some settings that can't be modified from within the application setting screen. Edit this 
file using a text editor if you want to modify settings such as "Display Local Drives", or "Display Common Folders" (just set the value 
to True or False). You can delete this file to restore default settings.


Keyboard shortcuts :
=================================

=General=
Echap: Go to "Computer"
F5: Refresh
F11: Full Screen
Arrow keys: navigate through items
Enter: open selected item
Del: delete selected item(s)
Backspace: navigate backward (history)
Alt + Left: navigate backward (history)
Alt + Right: navigate forward (history)
Alt + Up: navigate to parent folder
"+" or "-" : make the tiles bigger or smaller

=Photo viewer=
Arrow up: Zoom in
Arrow down: Zoom out
Arrow Left: Previous image
Arrow Right: Next image
Del: Delete the current image
Echap: exit the viewer

-The mouse Back/Next buttons can be used to switch to Previous/Next image.
-The mouse wheel can be used for Zooming In/Out. When the pointer is close to the bottom of the screen, the mouse wheel can also be used to switch to Previous/Next image.



What's new :
=================================

Version 1.7.2 (2020/04/12) :
-set the expiration date to 2020/05/10
-new: HEIC images and HEVC videos are supported on Windows 10 (if the Microsoft HEIC/HEIF and HEVC extensions are installed from the Microsoft Store)
-new: Pin folder to Taskbar
-improvement: in picture viewer, "Smart stretch" will now stretch 4:3 pictures on large screens
-new icon
-bug fixes

Version 1.7.1 (2019/10/17) :
-set the expiration date to 2019/10/31

Version 1.7.0 (2019/10/03) :
-set the expiration date to 2019/10/10
-new: tabs support
-new: live refresh of folder content
-fixed: video rotation metadata could not be read in certain conditions
-performance improvements

Version 1.6.0 (2018/04/16) :
-set the expiration date to 2018/04/25
-new: location bar can be clicked to navigate to a parent folder
-new: detection of MP4 video rotation metadata

Version 1.5.2 (2017/11/14) :
-set the expiration date to 2017/12/15
-bug fixes
-UI improvements (added spacing between groups in the navigation bar; 
added buttons to change the view, displayed only when toolbar has enough room for them)

Version 1.5.1 (2017/10/24) :
-set the expiration date to 2017/11/15
-new: file icons support
-fixed: small images had no thumbnail displayed in List view
-minor UI improvements

Version 1.5.0 (2017/10/06) :
-set the expiration date to 2017/10/25
-new: navigation bar
-new: folder content information in the status bar
-new: SHA256 hash calculation in file properties
-new: video preview can be rotated by the user
-improved UI
-fixed some performance issues in the picture viewer

Version 1.4.1 (2016/04/21) :
-set the expiration date to 2016/05/15
-setup improvements : added silent install/uninstall, and ability to deploy configuration files more easily
-files can be pinned to the Home screen
-common folders and local drives can be hidden (manually edit the .conf file to do so)
-ImmersiveExplorerFavoriteFolders.conf file can expand these environment variables: %userprofile% and "%public%
-improved visibility of tiles in White background mode
-other minor improvements

Version 1.4.0 (2016/01/31) :
-set the expiration date to 2016/02/15
-improved setup (packaged in a single EXE file)
-added the ability to disable the confirmation dialog that appears when opening files
-fixed issue with taskbar pinning

Version 1.3.5 (2016/01/19) :
-set the expiration date to 2016/02/01
-fixed: low resolution previews in the image viewer were displaying with an incorrect ratio

Version 1.3.4 (2015/12/14) :
-set the expiration date to 2016/01/20

Version 1.3.3 (2015/12/06) :
-set the expiration date to 2015/12/15
-digitally signed release
-file names on image tiles are now visible only when selection mode is active
-blur effect on wallpaper
-improved animations
-bug fixes

Version 1.3.2 (2015/11/15) :
-set the expiration date to 2015/12/01

Version 1.3.1 (2015/10/12) :
-set the expiration date to 2015/11/01
-folders can be pinned to the "Computer" screen (ability to pin to taskbar will come in the next version)
-ability to download language files is back
-updates are now checked over HTTPS (also applies to language files download)
-updated translation support

Version 1.3.0 (2015/08/23) :
-set the expiration date to 2015/09/05
-new: detailed list view (use the "Change view" button, "View as List")
-new: JPEG images and their thumbnail are rotated according to their EXIF information
-new: setting allowing to choose whether to use JPEG EXIF thumbnails when available, or use Windows Explorer thumbnail APIs every time
-new: after navigating back/forward, the previously selected item is selected again and scrolled into view
-new: command line argument now accepts both folders and files (useful if you want to set this app as your photo viewer in Windows Explorer)
-improved: videos are now properly centered when stretched, and seeking through a paused video now updates the image
-improved: keyboard scrolling in vertical list mode
-icons have been changed to better fit the Windows 10 style
-toolbar buttons are now displayed only in the mode in which they are relevant (browse mode or edit mode)

Version 1.2.0 (2015/04/25) :
-set the expiration date to 2015/05/10
-new: vertical scrolling
-new: "square" tiles
-new: ability to change the size of the tiles (keyboard shortcut: + or -)
-improved: shortcut opening dialog
-improved: taskbar shortcut icons (files, pictures, videos)

Version 1.1.4 (2015/04/10) :
-set the expiration date to 2015/04/20
-new: the file opening dialog displays the name of the associated app and its icon
-improved: performance when loading file type descriptions
-improved: minor visual changes

Version 1.1.3 (2015/04/01) :
-set the expiration date to 2015/04/10
-new: drive list is automatically refreshed when a drive/media is inserted/removed
-new: ability to sort by type
-improved: error handling when navigating to folder/drives that can't be loaded
-improved: minor visual changes
-fixed: visual bug when exiting full screen mode on Windows 7

Version 1.1.2 (2015/03/11) :
-set the expiration date to 2015/04/01
-fixed compatibility issue with Windows 10 Technical Preview 9926
-visual changes
-bug fixes

Version 1.1.1 (2014/12/25) :
-set the expiration date to 2015/01/15
-minor bug fix

Version 1.1.0 (2014/12/07) :
-set the expiration date to 2014/12/15
-upgraded from .NET Framework 4.0 to .NET Framework 4.5
-improved Aero Snap support
-added "Browse" and "Select" buttons (this change makes navigation and selection easier for touch-screen users)
-several minor improvements
-bug fixes


Version 1.0.9 (2014/10/05) :
-set the expiration date to 2014/11/01
-improved compatibility with Windows 10 Technical Preview

Version 1.0.8 (2014/07/21) :
-set the expiration date to 2014/08/20
-new: mouse wheel behavior default setting: Switch back/next if the pointer is near the top or bottom of the window - Zoom in/out otherwise
-improved: pinch-to-zoom support in the image viewer
-fixed: the window no longer bounces when scrolling using touch
-fixed: if the taskbar was docked at the top or the left of the screen, the window would be displayed at the wrong place when switching to full screen

Version 1.0.7 (2014/06/27) :
-new: mouse wheel behavior in the image viewer can be configured: zoom in/out (default), or next/previous
-new: folder previews can be disabled to improve performance (default setting is set during install depending on CPU and amount of RAM installed)
-new: images can be sent to the recycle bin by pressing the DEL key from within the image viewer
-improved: readability of the file and folder labels
-improved: refined user interface
-improved: dialog boxes keyboard support
-fixed: translation bug
-fixed: keyboard right key navigation bug
-fixed: folder thumbnail visual glitches

Version 1.0.6 (2014/06/20) :
-set the expiration date to 2014/07/20
-new: improved user interface
-fixed: scrolling performance issues while loading folder thumbnails or file descriptions

Version 1.0.5 (2014/05/22) :
-set the expiration date to 2014/06/20
-new: images can be stretched to fit the screen in the built-in image viewer (disabled by default)
-new: when using the Chinese (simplified or traditional) translation, text is displayed using the "Microsoft YaHei UI" font instead of "Segoe UI" for better readability
-improved: the folder content preview animation is less annoying (fading instead of sliding)
-improved: scrolling performance in folders containing images
-improved: folders thumbnails load time
-fixed: "Immersive Explorer Optimizer.exe" crash

Version 1.0.2 (2014/04/30) :
-set the expiration date to 2014/05/20
-new: animated GIF support in the image viewer
-new: images smaller than 400x400 are no longer streched by default in the image viewer
-new: "Immersive Explorer Optimizer.exe" will start right after you close Immersive Explorer for the 1st time
-new: "Immersive Explorer Optimizer.exe" has 2 execution modes (the standard mode will no longer force a complete NGEN rebuild)
-fixed: after scrolling forward then backward, the animation previewing the content of the subfolders was no longer displayed

Version 1.0.1 (2014/04/10) :
-set the expiration date to 2014/04/30
-file type descriptions are no longer hardcoded
-bug fixes

Version 1.0 (2014/03/19) :
-set the expiration date to 2014/04/10
-improved: image cache management
-fixed: some minor bugs
